<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    <strong>Student Management &nbsp;<a href="https://code-projects.org/">Brought To You By code-projects.org</a>.</strong>
  </footer>
